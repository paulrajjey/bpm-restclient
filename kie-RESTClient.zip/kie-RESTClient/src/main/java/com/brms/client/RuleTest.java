package com.brms.client;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.dmg.pmml.pmml_4_2.descr.Scorecard;
import org.drools.core.ClassObjectFilter;
import org.drools.core.marshalling.impl.ProtobufMessages.FactHandle;
import org.drools.pmml.pmml_4_2.ScoreCard;
import org.kie.api.KieServices;
import org.kie.api.builder.KieScanner;
import org.kie.api.builder.ReleaseId;
import org.kie.api.event.rule.AfterMatchFiredEvent;
import org.kie.api.event.rule.AgendaEventListener;
import org.kie.api.event.rule.AgendaGroupPoppedEvent;
import org.kie.api.event.rule.AgendaGroupPushedEvent;
import org.kie.api.event.rule.BeforeMatchFiredEvent;
import org.kie.api.event.rule.MatchCancelledEvent;
import org.kie.api.event.rule.MatchCreatedEvent;
import org.kie.api.event.rule.RuleFlowGroupActivatedEvent;
import org.kie.api.event.rule.RuleFlowGroupDeactivatedEvent;
import org.kie.api.logger.KieRuntimeLogger;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.StatelessKieSession;
import org.kie.api.runtime.rule.QueryResults;
import org.kie.api.runtime.rule.QueryResultsRow;

import citi.fraudpoc.AuthTransaction;
import citi.fraudpoc.MerchantTransaction;
import example.scorecarddemo.Employee;
import example.scorecarddemo.EmployeeScorecardOutput;
import example.scorecarddemo.Scorecard__calculatedScore;
import example.scorecarddemo.VacationScore;
import redhat.appointment.Patient;
import redhat.appointment.Question;
import redhat.appointment.QuestionRequest;
import redhatcentral.demo1.Product;


public class RuleTest {
    
    public KieContainer createContainer() {
    	System.out.println("kie container creation...");
    	KieServices ks = KieServices.Factory.get();
    	//ReleaseId rId = ks.newReleaseId("citi", "cbol", "1.1");
    	//ReleaseId rId = ks.newReleaseId("redhatcentral", "demo1", "1.3");
    	ReleaseId rId = ks.newReleaseId("redhat", "appointment", "1.0");
    	//ReleaseId rId = ks.newReleaseId("test", "Test", "1.4") ;
    	KieContainer kContainer = ks.newKieContainer(rId);
    	KieScanner scanner =  ks.newKieScanner(kContainer);
    	scanner.start(60000);
    	return kContainer;
    }
	public static void main(String[] args){
		
		RuleTest obj  = new RuleTest();
		
		//List<HashMap<String, String>> result = obj.balancesDisplayedForProductMap("HKGCB", "742", "1", "0");
		//obj.eventTest1();
		obj.eventTest3();
		//System.out.println(result);
	}
public void eventTest3(){
	KieServices ks = KieServices.Factory.get();
	//ReleaseId rId = ks.newReleaseId("citi", "cbol", "1.1");
	//ReleaseId rId = ks.newReleaseId("redhatcentral", "demo1", "1.3");
	ReleaseId rId = ks.newReleaseId("redhat", "appointment", "1.1");
	//ReleaseId rId = ks.newReleaseId("test", "Test", "1.4") ;
	KieContainer kContainer = ks.newKieContainer(rId);
		KieSession kSession = kContainer.newKieSession();
		KieRuntimeLogger logger;
    	logger = ks.getLoggers().newFileLogger(kSession, "/Users/JeyPaulraj/ruleaudit2");
		kSession.addEventListener(new AgendaEventListener() {
			
			public void matchCreated(MatchCreatedEvent event) {
				System.out.println("Rule name  ::" + event.getMatch().getRule().getName());
				
			}
			
			
			public void matchCancelled(MatchCancelledEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			
			public void beforeRuleFlowGroupDeactivated(RuleFlowGroupDeactivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void beforeRuleFlowGroupActivated(RuleFlowGroupActivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void beforeMatchFired(BeforeMatchFiredEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			
			public void agendaGroupPushed(AgendaGroupPushedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void agendaGroupPopped(AgendaGroupPoppedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void afterRuleFlowGroupDeactivated(RuleFlowGroupDeactivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void afterRuleFlowGroupActivated(RuleFlowGroupActivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void afterMatchFired(AfterMatchFiredEvent event) {
				System.out.println("afterMatchFired   ::" + event.getMatch().getRule().getName());
				
			}
		});
		
		Patient pateint = new Patient();
		
		pateint.setAge(19);
		
		  QuestionRequest request = new QuestionRequest();
	      request.setType("init");
	       List<Question> question = new ArrayList();
	       
	       
	       request.setQuestions(question);
	       
		kSession.insert(request);
        
		//kSession.insert(tr2);
		kSession.fireAllRules();
		for(Question quest :question ){
			
			System.out.println("ctest " +quest.getValue());
			System.out.println("ctest " +quest.getName());
		}
		
		//System.out.println(emp.getVacationScore());
		//System.out.println(emp.getLengthOfService());
		//System.out.println(emp.get());
		//kSession.getQueryResults(arg0, arg1);
		//Collection<? extends Object> ls1= kSession.getObjects(new ClassObjectFilter(ScoreCard.class));
		//Employee em = (Employee)kSession.getObject(handle);
		//System.out.println("codes scores     " + em.getVacationScore());
		
		//Collection<? extends Object> ls1= kSession.getObjects(new ClassObjectFilter(Scorecard__calculatedScore.class));
		
		/*System.out.println("size  " + ls1.size());
		for (Iterator iterator = ls1.iterator(); iterator.hasNext();) {
			Object object = (Object) iterator.next();
			
			if (object instanceof Scorecard__calculatedScore) {
				Scorecard__calculatedScore score = (Scorecard__calculatedScore) object;
			 
				System.out.println( "SCORE" + score.getValue());
				System.out.println( "SCORE" + score.toString());
				
			}
				
			
		}*/
		//System.out.println( "SCORE" + score.toString());
		//EmployeeScorecardOutput out = kSession.getobnew EmployeeScorecardOutput();
		
	/*	Collection<? extends Object> ls = kSession.getObjects();
		System.out.println("size  " + ls.size());
		for (Iterator iterator = ls.iterator(); iterator.hasNext();) {
			Object object = (Object) iterator.next();
			
			if (object instanceof EmployeeScorecardOutput) {
			  EmployeeScorecardOutput score = (EmployeeScorecardOutput) object;
			 
				System.out.println( score.getVacationScore());
				
			}
				
			
		}*/
		//kSession.getQueryResults("VacationScore", VacationScore);
		//EmployeeScorecard
		
		/*QueryResults results = kSession.getQueryResults( "VacationScore" ); 
		for ( QueryResultsRow row : results ) {
			Double classA = ( Double ) row.get( "$result" ); //you can retrieve all the bounded variables here
		    //do whatever you want with classA
			System.out.println("scorrrr" + classA);
		}*/
		
       // VacationScore score = new VacationScore();
        
		logger.close();
		//System.out.println(prod.getTax());
		
	}
	
	public void eventTest1(){
		
		KieSession kSession = createContainer().newKieSession();
		KieRuntimeLogger logger;
    	//logger = ks.getLoggers().newFileLogger(kSession, "/Users/JeyPaulraj/ruleaudit");
		kSession.addEventListener(new AgendaEventListener() {
			
			public void matchCreated(MatchCreatedEvent event) {
				System.out.println("Rule name  ::" + event.getMatch().getRule().getName());
				
			}
			
			
			public void matchCancelled(MatchCancelledEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			
			public void beforeRuleFlowGroupDeactivated(RuleFlowGroupDeactivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void beforeRuleFlowGroupActivated(RuleFlowGroupActivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void beforeMatchFired(BeforeMatchFiredEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			
			public void agendaGroupPushed(AgendaGroupPushedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void agendaGroupPopped(AgendaGroupPoppedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void afterRuleFlowGroupDeactivated(RuleFlowGroupDeactivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void afterRuleFlowGroupActivated(RuleFlowGroupActivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void afterMatchFired(AfterMatchFiredEvent event) {
				System.out.println("afterMatchFired   ::" + event.getMatch().getRule().getName());
				
			}
		});
		
		AuthTransaction tr1 = new AuthTransaction();
		
		tr1.setAccountId("1");
		tr1.setTransCountry("USA");
		tr1.setTransId(1);
		
		AuthTransaction tr2 = new AuthTransaction();
		tr2.setAccountId("1");
		tr2.setTransCountry("USA");
		tr2.setTransId(2);
		
		Product prod = new Product();
        prod.setName("Prod1");
        prod.setState("WI");
        
        Employee emp = new Employee();
        emp.setLengthOfService(6);
        emp.setVacation(10);
		//kSession.insert(prod);
        kSession.insert(emp);
        
		
		//kSession.insert(tr2);
		kSession.fireAllRules();
		System.out.println(emp.getVacationScore());
		//logger.close();
		//System.out.println(prod.getTax());
		
	}
	public void eventTest(){
		
    	KieSession kSession = createContainer().newKieSession();
    	MerchantTransaction trans = new MerchantTransaction();
    	trans.setAmount(6000);
    	trans.setCountry("SINGAPORE");
    	trans.setName("Jey");
    	trans.setTransactionDate(new Date());
    	trans.setTransactionType("DEPOSIT");

    	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    	Date d1 = null;
    	Date d2=null;
    	Date d3 =null;
		try {
			d1 = sdf.parse("02/05/2012");
			 d2 = sdf.parse("03/05/2012");
	    	 d3 = sdf.parse("01/05/2012");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    	
    	MerchantTransaction trans1 = new MerchantTransaction();
    	trans1.setAmount(6000);
    	trans1.setCountry("SINGAPORE");
    	trans1.setName("Jey");
    	trans1.setTransactionDate(d1);
    	trans1.setTransactionType("DEPOSIT");
    	
    	
    	MerchantTransaction trans2 = new MerchantTransaction();
    	trans2.setAmount(6000);
    	trans2.setCountry("SINGAPORE");
    	trans2.setName("Jey");
    	trans2.setTransactionDate(d2);
    	trans2.setTransactionType("DEPOSIT");
    	
    	
    	/*MerchantTransaction trans3 = new MerchantTransaction();
    	trans3.setAmount(6000);
    	trans3.setCountry("SINGAPORE");
    	trans3.setName("Jey");
    	trans3.setTransactionDate(d3);
    	trans3.setTransactionType("DEPOSIT");*/
    	
    	
    	kSession.addEventListener(new AgendaEventListener() {
			
			public void matchCreated(MatchCreatedEvent event) {
				System.out.println("Rule name  ::" + event.getMatch().getRule().getName());
				
			}
			
			
			public void matchCancelled(MatchCancelledEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			
			public void beforeRuleFlowGroupDeactivated(RuleFlowGroupDeactivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void beforeRuleFlowGroupActivated(RuleFlowGroupActivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void beforeMatchFired(BeforeMatchFiredEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			
			public void agendaGroupPushed(AgendaGroupPushedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void agendaGroupPopped(AgendaGroupPoppedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void afterRuleFlowGroupDeactivated(RuleFlowGroupDeactivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void afterRuleFlowGroupActivated(RuleFlowGroupActivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void afterMatchFired(AfterMatchFiredEvent event) {
				System.out.println("afterMatchFired   ::" + event.getMatch().getRule().getName());
				
			}
		});
    	//DisplayBalance db = new DisplayBalance("100", null, null );
    //	kSession.setGlobal( "list", list );
	}
	
	
	public List<HashMap<String, String>> balancesDisplayedForProductMap( String businessCode,
    		 String transactionType,
    		 String productType,
    		 String subProductType) {
    	
    	System.out.println("teting .. rules ");
    	HashMap<String, String> input = new HashMap<String, String>();
    	input.put("businessCode", businessCode);
    	input.put("transactionType", transactionType);
    	input.put("productType", productType);
    	input.put("subProductType", subProductType);
    	//Transaction transaction = new Transaction();
    	//transaction.setInput("100");
    	List<HashMap<String, String>> list = new ArrayList<HashMap<String, String>>();
    	
    	StatelessKieSession kSession = createContainer().newStatelessKieSession();
    	//KieSession kSession = createContainer().newKieSession();
    	kSession.addEventListener(new AgendaEventListener() {
			
			public void matchCreated(MatchCreatedEvent event) {
				System.out.println("Rule name  ::" + event.getMatch().getRule().getName());
				
			}
			
			
			public void matchCancelled(MatchCancelledEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			
			public void beforeRuleFlowGroupDeactivated(RuleFlowGroupDeactivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void beforeRuleFlowGroupActivated(RuleFlowGroupActivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void beforeMatchFired(BeforeMatchFiredEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			
			public void agendaGroupPushed(AgendaGroupPushedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void agendaGroupPopped(AgendaGroupPoppedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void afterRuleFlowGroupDeactivated(RuleFlowGroupDeactivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void afterRuleFlowGroupActivated(RuleFlowGroupActivatedEvent event) {
				// TODO Auto-generated method stub
				
			}
			
			public void afterMatchFired(AfterMatchFiredEvent event) {
				System.out.println("afterMatchFired   ::" + event.getMatch().getRule().getName());
				
			}
		});
    	//DisplayBalance db = new DisplayBalance("100", null, null );
    	kSession.setGlobal( "list", list );
    	kSession.execute(input);
    	//kSession.fireAllRules();
    	//System.out.println("Output :: "+transaction.getOutput());
    	return list;
    }
}
