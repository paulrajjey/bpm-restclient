package com.brms.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.math3.stat.descriptive.summary.Product;
import org.drools.core.command.impl.GenericCommand;
import org.drools.core.command.runtime.BatchExecutionCommandImpl;
import org.drools.core.command.runtime.rule.FireAllRulesCommand;
import org.drools.core.command.runtime.rule.InsertObjectCommand;
import org.drools.core.command.runtime.rule.QueryCommand;
import org.drools.core.runtime.impl.ExecutionResultImpl;
import org.kie.api.KieServices;
import org.kie.api.command.BatchExecutionCommand;
import org.kie.api.command.Command;
import org.kie.api.command.KieCommands;
import org.kie.internal.runtime.helper.BatchExecutionHelper;
import org.kie.server.api.marshalling.Marshaller;
import org.kie.server.api.marshalling.MarshallerFactory;
import org.kie.server.api.marshalling.MarshallingFormat;
import org.kie.server.api.model.KieContainerResource;
import org.kie.server.api.model.KieContainerResourceList;
import org.kie.server.api.model.ReleaseId;
import org.kie.server.api.model.ServiceResponse;
import org.kie.server.api.model.ServiceResponse.ResponseType;
import org.kie.server.api.model.definition.ProcessDefinition;
import org.kie.server.api.model.instance.NodeInstance;
import org.kie.server.api.model.instance.ProcessInstance;
import org.kie.server.api.model.instance.TaskSummary;
import org.kie.server.client.KieServicesClient;
import org.kie.server.client.KieServicesConfiguration;
import org.kie.server.client.KieServicesFactory;
import org.kie.server.client.ProcessServicesClient;
import org.kie.server.client.QueryServicesClient;
import org.kie.server.client.RuleServicesClient;
import org.kie.server.client.UserTaskServicesClient;

import redhat.ruledemo.Applicant;
import redhatdemo.Productdemo;
import baincapital.baindemo.CreditCardTransaction;
import citi.fraud.domain.Transaction;
import citi.prsruleengine.Attribute;
import citi.prsruleengine.FieldRequest;
import example.demoprocess.DemoTransaction;

import com.highmark.domain.RiskLevel;
//import citi.PRSruleengine.FieldRequest;

public class ProcessServiceClient {


    public static void main(String[] args) throws Exception {
        long start = System.currentTimeMillis();
       String serverUrl = "http://localhost:8580/kie-server/services/rest/server";
        String user = "bpmsAdmin";
        //String serverUrl = "http://10.0.2.15:9080/kie-server/services/rest/server";
        //String user = "jpaulraj";
        String password = "jboss123$";
       String containerId = "redhatdemo";

       // String processId = "hiring";
       
        
        Set<Class<?>> classes = new HashSet<Class<?>>();
        //classes.add(User.class);
      //  classes.add(RiskLevel.class);
        Marshaller marshaller = MarshallerFactory.getMarshaller(classes,  MarshallingFormat.XSTREAM, Main.class.getClassLoader());
       // KieServicesConfiguration configuration = KieServicesFactory.newRestConfiguration(serverUrl, user, password);
        KieServicesClient  kieServicesClient = ProcessServiceClient.configure(serverUrl, user, password);
        
     
       // RuleServicesClient ruleClient = kieServicesClient.getServicesClient(RuleServicesClient.class);
        ProcessServicesClient processClient = kieServicesClient.getServicesClient(ProcessServicesClient.class);
        Map<String , Object> param = new HashMap<String, Object>();
        
        Productdemo product = new Productdemo();
        product.setId("1001");
        product.setName("demo");
        product.setPrice(100);
        product.setState("WI");
        
        DemoTransaction tr = new DemoTransaction();
        tr.setName("Jey");
        tr.setTransId(1001);
        tr.setNumOfItems(10);
        tr.setState("WI");
      
        //param.put("name", "bpmsAdmin");
        
        //Long id = processClient.startProcess(containerId, "DemoProcess.demoProcess", param);
        Long id = processClient.startProcess(containerId, "redhatdemo.redhatdemoprocess", param);
       
        System.out.println("Process statred " + id);
        
        
        System.out.println("Execution completed in " + (System.currentTimeMillis() - start));

    }
    
public static KieServicesClient configure(String url, String username, String password) {
		
		//default marshalling format is JAXB
		KieServicesConfiguration config = KieServicesFactory.newRestConfiguration(url, username, password);
		
	
		
		//alternatives
		
		config.setMarshallingFormat(MarshallingFormat.XSTREAM);
		//config.setMarshallingFormat(MarshallingFormat.JSON);

	
		Set<Class<?>> allClasses = new HashSet<Class<?>>();
		//allClasses.add(com.highmark.domain.RiskLevel.class);
		/*allClasses.add(org.drools.core.command.runtime.rule.FireAllRulesCommand.class);
		allClasses.add(org.drools.core.command.runtime.rule.InsertObjectCommand.class);
		allClasses.add(org.drools.core.common.DefaultFactHandle.class);
		allClasses.add(org.drools.core.command.runtime.rule.GetObjectCommand.class);*/
		//config.addJaxbClasses(allClasses);
		return KieServicesFactory.newKieServicesClient(config);
		//
	}

}