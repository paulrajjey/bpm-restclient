package com.brms.client;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.drools.core.command.impl.GenericCommand;
import org.drools.core.command.runtime.BatchExecutionCommandImpl;
import org.drools.core.command.runtime.DisposeCommand;
import org.drools.core.command.runtime.rule.FireAllRulesCommand;
import org.drools.core.command.runtime.rule.InsertObjectCommand;
import org.drools.core.command.runtime.rule.QueryCommand;
import org.drools.core.runtime.impl.ExecutionResultImpl;
import org.kie.api.command.BatchExecutionCommand;
import org.kie.internal.runtime.helper.BatchExecutionHelper;
import org.kie.server.api.marshalling.Marshaller;
import org.kie.server.api.marshalling.MarshallerFactory;
import org.kie.server.api.marshalling.MarshallingFormat;
import org.kie.server.api.model.KieContainerResource;
import org.kie.server.api.model.KieContainerResourceList;
import org.kie.server.api.model.ReleaseId;
import org.kie.server.api.model.ServiceResponse;
import org.kie.server.api.model.definition.ProcessDefinition;
import org.kie.server.api.model.instance.NodeInstance;
import org.kie.server.api.model.instance.ProcessInstance;
import org.kie.server.api.model.instance.TaskSummary;
import org.kie.server.client.KieServicesClient;
import org.kie.server.client.KieServicesConfiguration;
import org.kie.server.client.KieServicesFactory;
import org.kie.server.client.ProcessServicesClient;
import org.kie.server.client.QueryServicesClient;
import org.kie.server.client.RuleServicesClient;
import org.kie.server.client.UserTaskServicesClient;

import redhat.healthcaredemotest.PatientDiagnosisInfo;
import redhat.ruledemo.Applicant;
import redhatcentral.demo1.Product;
import baincapital.baindemo.CreditCardTransaction;
import example.brms64test.Application;

import com.highmark.domain.RiskLevel;

public class DecisionServiceClient2 {


    public static void main(String[] args) throws Exception {
        long start = System.currentTimeMillis();
       String serverUrl = "http://localhost:8080/kie-server/services/rest/server";
        String user = "brmsAdmin";
        //String serverUrl = "http://10.0.2.15:9080/kie-server/services/rest/server";
        //String user = "jpaulraj";
        String password = "jboss123$";
       // String containerId = "claimservice";

      
       // String processId = "hiring";
       
        
        Set<Class<?>> classes = new HashSet<Class<?>>();
        //classes.add(User.class);
        classes.add(RiskLevel.class);
        Marshaller marshaller = MarshallerFactory.getMarshaller(classes,  MarshallingFormat.XSTREAM, Main.class.getClassLoader());
       // KieServicesConfiguration configuration = KieServicesFactory.newRestConfiguration(serverUrl, user, password);
        KieServicesClient  kieServicesClient = DecisionServiceClient2.configure(serverUrl, user, password);
        
       // configuration.setMarshallingFormat(MarshallingFormat.JAXB);
//      
        List<GenericCommand<?>> commands = new ArrayList<GenericCommand<?>>();
        
        
        //String containerId = "test"; 
        String containerId =  "healthcaredemo1";
        
        // add fact to insert command 
        // brmstestdemo(commands);
       
        healthcaredemo(commands);
        
        FireAllRulesCommand fireAllRulesCommand = new FireAllRulesCommand();
        DisposeCommand dcomand = new DisposeCommand();
        commands.add(fireAllRulesCommand);
    
        BatchExecutionCommand command = new BatchExecutionCommandImpl(commands);
        String xStreamXml = BatchExecutionHelper.newXStreamMarshaller().toXML(command); // actual XML request
        System.out.println("\t######### Rules request"  + xStreamXml);
        
        
        
        RuleServicesClient ruleClient = kieServicesClient.getServicesClient(RuleServicesClient.class);
        ServiceResponse<String> result = ruleClient.executeCommands(containerId, command);
     
        String resut = result.getResult();
      

        ExecutionResultImpl results = marshaller.unmarshall(resut, ExecutionResultImpl.class);
       
        //reponse from server
        
       // brmstestdemoResult(results);
        
        healthcaredemoResult(results);
        
        
        System.out.println("\t######### Rules executed" + result.toString());
        
        System.out.println("\t######### Rules result1" + result.getResult());
        System.out.println("\t######### Rules result1" + result.getType());
        
        System.out.println("Execution completed in " + (System.currentTimeMillis() - start));

    }
    public static void healthcaredemo(List<GenericCommand<?>> commands){
    	PatientDiagnosisInfo pat = new PatientDiagnosisInfo();
    	
    	pat.setAge(18);
    	pat.setGfr(40);
    	pat.setName("Jey");
    	InsertObjectCommand insertObjectCommand = new InsertObjectCommand();
        insertObjectCommand.setOutIdentifier("DiagResponse");
        insertObjectCommand.setObject(pat);
        commands.add(insertObjectCommand);
    
    } 
    
    
    
    public static void healthcaredemoResult(ExecutionResultImpl results){
    	
    	PatientDiagnosisInfo pat = (PatientDiagnosisInfo)results.getValue("DiagResponse");
        
        //  RiskLevel level = marshaller.unmarshall(resut, RiskLevel.class)	; 
          		
          
          System.out.println("Diagnosis Satge " + pat.getStage());
    	
    } 
    public static void brmstestdemo( List<GenericCommand<?>> commands){
    	  Application app = new Application();
          app.setAge(18);
          app.setName("Jey Paulraj");
          
          InsertObjectCommand insertObjectCommand = new InsertObjectCommand();
          insertObjectCommand.setOutIdentifier("Application");
          insertObjectCommand.setObject(app);
          commands.add(insertObjectCommand);
    	
    } 
    public static void brmstestdemoResult(ExecutionResultImpl results){
    	
    	Application appl = (Application)results.getValue("Application");
        
        //  RiskLevel level = marshaller.unmarshall(resut, RiskLevel.class)	; 
          		
          
          System.out.println("result tax" + appl.getTax());
          
          
         
    	
    } 
    public static KieServicesClient configure(String url, String username, String password) {
		
		//default marshalling format is JAXB
		KieServicesConfiguration config = KieServicesFactory.newRestConfiguration(url, username, password);
		
	
		
		//alternatives
		
		config.setMarshallingFormat(MarshallingFormat.XSTREAM);
		//config.setMarshallingFormat(MarshallingFormat.JSON);

	
		Set<Class<?>> allClasses = new HashSet<Class<?>>();
		//allClasses.add(com.highmark.domain.RiskLevel.class);
		/*allClasses.add(org.drools.core.command.runtime.rule.FireAllRulesCommand.class);
		allClasses.add(org.drools.core.command.runtime.rule.InsertObjectCommand.class);
		allClasses.add(org.drools.core.common.DefaultFactHandle.class);
		allClasses.add(org.drools.core.command.runtime.rule.GetObjectCommand.class);*/
		//config.addJaxbClasses(allClasses);
		return KieServicesFactory.newKieServicesClient(config);
		//
	}

}