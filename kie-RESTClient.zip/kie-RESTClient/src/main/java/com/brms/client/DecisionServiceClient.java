package com.brms.client;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.drools.core.command.impl.GenericCommand;
import org.drools.core.command.runtime.BatchExecutionCommandImpl;
import org.drools.core.command.runtime.DisposeCommand;
import org.drools.core.command.runtime.rule.FireAllRulesCommand;
import org.drools.core.command.runtime.rule.InsertObjectCommand;
import org.drools.core.command.runtime.rule.QueryCommand;
import org.drools.core.runtime.impl.ExecutionResultImpl;
import org.kie.api.command.BatchExecutionCommand;
import org.kie.internal.runtime.helper.BatchExecutionHelper;
import org.kie.server.api.marshalling.Marshaller;
import org.kie.server.api.marshalling.MarshallerFactory;
import org.kie.server.api.marshalling.MarshallingFormat;
import org.kie.server.api.model.KieContainerResource;
import org.kie.server.api.model.KieContainerResourceList;
import org.kie.server.api.model.ReleaseId;
import org.kie.server.api.model.ServiceResponse;
import org.kie.server.api.model.definition.ProcessDefinition;
import org.kie.server.api.model.instance.NodeInstance;
import org.kie.server.api.model.instance.ProcessInstance;
import org.kie.server.api.model.instance.TaskSummary;
import org.kie.server.client.KieServicesClient;
import org.kie.server.client.KieServicesConfiguration;
import org.kie.server.client.KieServicesFactory;
import org.kie.server.client.ProcessServicesClient;
import org.kie.server.client.QueryServicesClient;
import org.kie.server.client.RuleServicesClient;
import org.kie.server.client.UserTaskServicesClient;

import redhat.ruledemo.Applicant;
import redhatcentral.demo1.Product;
import baincapital.baindemo.CreditCardTransaction;

import com.highmark.domain.RiskLevel;

public class DecisionServiceClient {


    public static void main(String[] args) throws Exception {
        long start = System.currentTimeMillis();
       String serverUrl = "http://localhost:8080/kie-server/services/rest/server";
        String user = "bpmsAdmin";
        //String serverUrl = "http://10.0.2.15:9080/kie-server/services/rest/server";
        //String user = "jpaulraj";
        String password = "jboss123$";
       // String containerId = "claimservice";

       String containerId = "baincapital";
       // String processId = "hiring";
       
        
        Set<Class<?>> classes = new HashSet<Class<?>>();
        //classes.add(User.class);
        classes.add(RiskLevel.class);
        Marshaller marshaller = MarshallerFactory.getMarshaller(classes,  MarshallingFormat.XSTREAM, Main.class.getClassLoader());
       // KieServicesConfiguration configuration = KieServicesFactory.newRestConfiguration(serverUrl, user, password);
        KieServicesClient  kieServicesClient = DecisionServiceClient.configure(serverUrl, user, password);
        
       // configuration.setMarshallingFormat(MarshallingFormat.JAXB);
//      
        List<GenericCommand<?>> commands = new ArrayList<GenericCommand<?>>();
       // BatchExecutionCommandImpl executionCommand = new BatchExecutionCommandImpl(commands);
       // executionCommand.setLookup("defaultKieSession");

        CreditCardTransaction card = new CreditCardTransaction();
        card.setAge(26);
        card.setState("WI");
        card.setType("VISA");
        
        Applicant app = new Applicant();
        app.setScore(650);
        app.setAge(45);
        Product prod = new Product();
        prod.setName("Prod1");
        prod.setState("WI");
       
        
        
        
        InsertObjectCommand insertObjectCommand = new InsertObjectCommand();
        insertObjectCommand.setOutIdentifier("Product");
        insertObjectCommand.setObject(prod);

        /*QueryCommand queryCommand = new QueryCommand();

        queryCommand.setName("persons");

        queryCommand.setOutIdentifier("persons");
        
        
		GetObjectsCommand getObjectsCommand = new GetObjectsCommand();

		getObjectsCommand.setOutIdentifier("objects");
         */
        //command.getCommands().add(queryCommand);
        
        FireAllRulesCommand fireAllRulesCommand = new FireAllRulesCommand();
        DisposeCommand dcomand = new DisposeCommand();
       // commands.add(dcomand);
        //commands.add(insertObjectCommand);
        commands.add(insertObjectCommand);
        commands.add(fireAllRulesCommand);
        //commands.add(queryCommand);
       
        BatchExecutionCommand command = new BatchExecutionCommandImpl(commands);
        String xStreamXml = BatchExecutionHelper.newXStreamMarshaller().toXML(command); // actual XML request
        System.out.println("\t######### Rules request"  + xStreamXml);
        
       /* RuleServicesClient ruleClient = kieServicesClient.getServicesClient(RuleServicesClient.class);
        //ruleClient.executeCommands(containerId, executionCommand);
        ServiceResponse<String> result = ruleClient.executeCommands(containerId, command);
      //  ruleClient.executeCommands(containerId, xStreamXml);
        
        String resut = result.getResult();
      //  RiskLevel level = new RiskLevel();
        		// BatchExecutionHelper.newXStreamMarshaller().fromXML(resut,level);
       // 

        ExecutionResultImpl results = marshaller.unmarshall(resut, ExecutionResultImpl.class);
       
        Applicant maxamount = (Applicant)results.getValue("maximumAmount");
        
      //  RiskLevel level = marshaller.unmarshall(resut, RiskLevel.class)	; 
        		
        
        System.out.println("maximum amount " + maxamount.getCreditAmount());
        
        System.out.println("output " + maxamount.toString());
        
        System.out.println("\t######### Rules executed" + result.toString());
        
        System.out.println("\t######### Rules result1" + result.getResult());
        System.out.println("\t######### Rules result1" + result.getType());
        
        
        System.out.println("Execution completed in " + (System.currentTimeMillis() - start));*/

    }
    
public static KieServicesClient configure(String url, String username, String password) {
		
		//default marshalling format is JAXB
		KieServicesConfiguration config = KieServicesFactory.newRestConfiguration(url, username, password);
		
	
		
		//alternatives
		
		config.setMarshallingFormat(MarshallingFormat.XSTREAM);
		//config.setMarshallingFormat(MarshallingFormat.JSON);

	
		Set<Class<?>> allClasses = new HashSet<Class<?>>();
		//allClasses.add(com.highmark.domain.RiskLevel.class);
		/*allClasses.add(org.drools.core.command.runtime.rule.FireAllRulesCommand.class);
		allClasses.add(org.drools.core.command.runtime.rule.InsertObjectCommand.class);
		allClasses.add(org.drools.core.common.DefaultFactHandle.class);
		allClasses.add(org.drools.core.command.runtime.rule.GetObjectCommand.class);*/
		//config.addJaxbClasses(allClasses);
		return KieServicesFactory.newKieServicesClient(config);
		//
	}

}