package com.brms.client;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.drools.core.command.runtime.rule.InsertObjectCommand;
import org.drools.core.command.runtime.rule.QueryCommand;
import org.kie.api.command.BatchExecutionCommand;
import org.kie.api.command.Command;
import org.kie.internal.command.CommandFactory;
import org.kie.internal.runtime.helper.BatchExecutionHelper;

import com.redhat.empactpoc.agencycontrol.AgencyControlRequestType;

import cibc.cibccepproj.cibcTradeEvent;
import example.decisonengine.CreditTransacton;
import example.healthcare.Patient;
import example.project4.TestObj;
import example.scorecard2.Customer;
import example.scorecarddemo.Employee;
import redhat.appointment.Question;
import redhat.appointment.QuestionRequest;
import redhat.shipping.ReturnOrder;
import wiley.usecase.Usecase1Domain;
import wiley.usecase.Usecase2Domain;
import wiley.wileybrmsdemo.Application;



public class RuleXmlPayload {

	public static String marshelxml(){
	    
	
		AgencyControlRequestType agencyControlRequestType = new AgencyControlRequestType();
		
		agencyControlRequestType.setAgencyCode("KYK");
		agencyControlRequestType.setOrigin("LHR");
		agencyControlRequestType.setDestination("AMS");
		agencyControlRequestType.setPNR("10001");
		agencyControlRequestType.setTicketCounter(9);
		
		Employee emp = new Employee();
		emp.setLengthOfService(5);
		emp.setVacation(10);
		TestObj obj = new TestObj();
		List<Command> commands = new ArrayList<Command>()	;
		obj.setName("jey");
		Customer cus = new Customer();
		cus.setAge(6);
		cus.setName("Jey");
		cus.setState("WI");
		
		cibcTradeEvent event = new cibcTradeEvent();
		event.setTradeAmount(20001);
		event.setCustomerName("Jey");
		
		CreditTransacton tran = new CreditTransacton();
		tran.setAmount(2000);
		
		ReturnOrder order = new ReturnOrder();
		order.setOrderId("1001");
		order.setMerchantName("1001");
		order.setSkuValue(10);
		order.setCalculatedInCountryReturnCost(10);
		
		
		
		Application app = new Application();
		app.setName("Jey");
		app.setCity("WI");
		Usecase2Domain domain = new Usecase2Domain();
		/*tenant_id": "4567",
        "tenant_name": "UOF",
        "assignment_id": "a123",
        "student_id": "stu123",
        "question_id": [
                        "qid1234",
                        "qid2345",
                        "qid4567",
                        "qid890",
                        "qid876",
                        "qid8763",
                        "qid3456",
                        "qid75435",
                        "qid76443"*/
		String[] arr = new String []{
                        "qid1234",
                        "qid2345",
                        "qid4567",
                        "qid890",
                        "qid876",
                        "qid8763",
                        "qid3456",
                        "qid75435",
                        "qid76443"};
		
		domain.setTenantId("4567");
        domain.setAssignmentId("UOF");     
        domain.setStudentId("a123");
        List<String> questions = new ArrayList<String>();
        questions = new ArrayList<String>(Arrays.asList(arr));

       domain.setQuestions(questions);
       
       Usecase2Domain domain1 = new Usecase2Domain();
       domain1.setCurrentAttempt(3);
       domain1.setAllowedScoringAfterMaxTries("Y");
       //domain.setQuestionId(questionId);
                        
       Usecase1Domain usedomain1 = new Usecase1Domain();
       usedomain1.setBundleCode("CPOL");
       usedomain1.setBOERRRenewalSubType("RR");
       usedomain1.setBundleGroupCode("RP");
       
       QuestionRequest request = new QuestionRequest();
       request.setType("init");
       List<Question> question = new ArrayList();
       
       
       request.setQuestions(question);
       
       Patient patient = new Patient();
       patient.setAge(13);
       patient.setName("John");
       
      // CommandFactory.newQuery( "$patients", "Intake Results" );
       QueryCommand qcommand = new QueryCommand("queryResponse", "findQuestion", new Object[]{"Toddler"});
        //BatchExecutionCommand batchExecutionCommand = CommandFactory.newBatchExecution(commands);
		BatchExecutionCommand batchExecutionCommand = CommandFactory.newBatchExecution(commands);
       
       //query "Intake Results"
       //Valid( $patients : value )
       //end
		//commands.add( CommandFactory.newQuery( "$patients", "Intake Results" ) );
		 //insert fact 
       // InsertObjectCommand insertObjectCommand = new InsertObjectCommand(agencyControlRequestType,"Response");
        InsertObjectCommand insertObjectCommand = new InsertObjectCommand(patient,"Response");
        
       // InsertObjectCommand insertObjectCommand1 = new InsertObjectCommand(prodconfig);
       
        //InsertObjectCommand list1 = new InsertObjectCommand(ls, "ls");
        //InsertObjectCommand insertObjectCommand2 = new InsertObjectCommand(per1);
        //InsertObjectCommand insertObjectCommand1 = new InsertObjectCommand(tr);
        //InsertObjectCommand insertObjectCommand = new InsertObjectCommand(model);
        
         //insertObjectCommand.setOutIdentifier("output");
       //insertObjectCommand1.setOutIdentifier("output");
       // insertObjectCommand.setEntryPoint("count");
       
       
        
        
        Command fireAllRulesCommand = CommandFactory.newFireAllRules();
       // Command startProces =   CommandFactory.newStartProcess("Jey");
        commands.add(insertObjectCommand);
        commands.add(qcommand);
     //  commands.add(startProces);
        commands.add(fireAllRulesCommand);

        String result = BatchExecutionHelper.newXStreamMarshaller().toXML(batchExecutionCommand);
        System.out.println(result);
        return result;
		
	}
	public static void main(String arq[]){
		//generate payload to test rule
		String payLoad = RuleXmlPayload.marshelxml();
		
		/*CredentialsProvider credsProvider = new BasicCredentialsProvider();
		Credentials credi = (Credentials)new UsernamePasswordCredentials("username", "password");
        credsProvider.setCredentials(
                new AuthScope("localhost", 8080),
                credi);
        CloseableHttpClient httpClient2 = HttpClients.custom()
                .setDefaultCredentialsProvider(credsProvider)
                .build();
        try {
            HttpPost httppost = new HttpPost("http://localhost/");
            httppost.addHeader("content-type", "application/xml");
            
            httppost.setEntity(new StringEntity(payLoad));
            System.out.println("Executing request " + httppost.getRequestLine());
            CloseableHttpResponse response1 = httpClient2.execute(httppost);
           
                System.out.println("----------------------------------------");
                System.out.println(response1.getStatusLine());
                
					EntityUtils.consume(response1.getEntity());
				
					httpClient2.close();1
        } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
        	
        }*/


		
	}
}
