package com.brms.client;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.drools.core.command.runtime.process.StartProcessCommand;
import org.drools.core.command.runtime.rule.InsertElementsCommand;
import org.drools.core.command.runtime.rule.InsertObjectCommand;
import org.kie.api.command.BatchExecutionCommand;
import org.kie.api.command.Command;
import org.kie.internal.command.CommandFactory;
import org.kie.internal.runtime.helper.BatchExecutionHelper;

import citi.scorecard.ScoreCard;
import citi.scorecard.ScoreCardData;
import citi.scorecard.ScoreFormula;
import citi.scorecard.SegmentConsant;





public class RuleScoreCardXmlPayload {

	public static String marshelxml(){
	    
	
		//Score card inpput
		List<Command> commands = new ArrayList<Command>()	;
		
    	ScoreCard scoreCard = new ScoreCard();
    	Map<String, BigDecimal> params = new HashMap<String, BigDecimal>();
    	
    	List<ScoreFormula> scoreFormulas = new ArrayList<ScoreFormula>();
    	
    	ScoreFormula ADV124value =new ScoreFormula();
    	ADV124value.setKey("ADV124");
    	ADV124value.setValue(0.08);
    	
    	ScoreFormula Balsqrtvalue =new ScoreFormula();
    	Balsqrtvalue.setKey("Balsqrt");
    	Balsqrtvalue.setValue(2);
    	
    	ScoreFormula CB0_ATTR012Value =new ScoreFormula();
    	CB0_ATTR012Value.setKey("CB0_ATTR012");
    	CB0_ATTR012Value.setValue(11);
    	
    	
    	
    	params.put("ADV124",new BigDecimal(0.08));
    	params.put("Balsqrt",new BigDecimal(2));
    	params.put("CB0_ATTR012",new BigDecimal(11));
    	
    	scoreFormulas.add(ADV124value);
    	scoreFormulas.add(Balsqrtvalue);

    	scoreFormulas.add(CB0_ATTR012Value);

    	//card.setParams(params);;
    	scoreCard.setParams(scoreFormulas);
    	scoreCard.setSegmentId(3);
    	
    	//Segment constant 
    	SegmentConsant segmentConstant = new SegmentConsant();
    	segmentConstant.setSegmentConstant(-1.2711);
    	segmentConstant.setSegmentId(3);
    	
    	//Score card data for correnspondng segment
    	
    	ScoreCardData dataADV124 = new ScoreCardData();
    	dataADV124.setSegmentId(3);
    	dataADV124.setFormula("ADV124");
    	dataADV124.setMissValue(0.9);
    	dataADV124.setCoef(0.8567);
    	dataADV124.setReason(61);
    	//data.setMinValue(0.07);
    	dataADV124.setMinValue(0.07);
    	dataADV124.setMaxValue(0.99);
    	dataADV124.setMean(0.35);
    	//dataADV124.setTransx("SQRT(X)");
    	
    	ScoreCardData ADV221 = new ScoreCardData();
    	ADV221.setSegmentId(3);
    	ADV221.setFormula("ADV221");
    	ADV221.setMissValue(0.1);
    	ADV221.setMinValue(0);
    	ADV221.setMaxValue(0.83);
    	//ADV221.setTransx("SQRT(X)");
    	ADV221.setCoef(0.953);
    	ADV221.setReason(18);
    	ADV221.setMean(0.025);

    	
    	ScoreCardData Balsqrt = new ScoreCardData();
    	Balsqrt.setSegmentId(3);
    	Balsqrt.setFormula("Balsqrt");
    	Balsqrt.setMissValue(1);
    	Balsqrt.setMinValue(1);
    	Balsqrt.setMaxValue(53);
    	//Balsqrt.setTransx("SQRT(X)");
    	Balsqrt.setCoef(0.0155);
    	Balsqrt.setReason(59);
    	Balsqrt.setMean(22.5);

    	
    	
       
    	ScoreCardData CB0_ATTR012  = new ScoreCardData();
    	CB0_ATTR012.setSegmentId(3);
    	CB0_ATTR012.setFormula("CB0_ATTR012");
    	CB0_ATTR012.setMissValue(50);
    	CB0_ATTR012.setMinValue(12);
    	CB0_ATTR012.setMaxValue(196);
    	//CB0_ATTR012.setTransx("SQRT(X)");
    	CB0_ATTR012.setCoef(-0.0080);
    	CB0_ATTR012.setReason(58);
    	CB0_ATTR012.setMean(150.1);
    	
    	
    	
    	
    	
    	ScoreCardData CB0_ATTR061   = new ScoreCardData();
    	CB0_ATTR061.setSegmentId(3);
    	CB0_ATTR061.setFormula("CB0_ATTR061");
    	CB0_ATTR061.setMissValue(300);
    	CB0_ATTR061.setMinValue(0);
    	CB0_ATTR061.setMaxValue(473);
    	CB0_ATTR061.setTransx("SQRT(X)");
    	CB0_ATTR061.setCoef(0.0077);
    	CB0_ATTR061.setReason(101);
    	CB0_ATTR061.setMean(8.8);
    
    	ScoreCardData CB0_ATTR306  = new ScoreCardData();
    	CB0_ATTR306.setSegmentId(3);
    	CB0_ATTR306.setFormula("CB0_ATTR306");
    	CB0_ATTR306.setMissValue(5);
    	CB0_ATTR306.setMinValue(0);
    	CB0_ATTR306.setMaxValue(10);
    	//CB0_ATTR306.setTransx("SQRT(X)");
    	CB0_ATTR306.setCoef(0.0883);
    	CB0_ATTR306.setReason(83);
    	CB0_ATTR306.setMean(1.072);
    	
    	
        
        ScoreCardData payrate  = new ScoreCardData();
        payrate.setSegmentId(3);
        payrate.setFormula("payrate");
        payrate.setMissValue(0.1);
        payrate.setMinValue(0);
        payrate.setMaxValue(0.55);
      //payrate.setTransx("SQRT(X)");
        payrate.setCoef(-1.1424);
        payrate.setReason(94);
        payrate.setMean(0.23);
    	
        List scordCardData = new ArrayList();
        scordCardData.add(segmentConstant);
       /* scordCardData.add(dataADV124);
        scordCardData.add(ADV221);
        scordCardData.add(Balsqrt);
        scordCardData.add(CB0_ATTR012);
        scordCardData.add(CB0_ATTR061);
        scordCardData.add(CB0_ATTR306);
        scordCardData.add(payrate)*/;
        
        StartProcessCommand processCommand = new StartProcessCommand("scorecard.scorecardprocessruleflow");
       
        //BatchExecutionCommand batchExecutionCommand = CommandFactory.newBatchExecution(commands);
		BatchExecutionCommand batchExecutionCommand = CommandFactory.newBatchExecution(commands);
		
		InsertElementsCommand scorcardDataCommand  = new InsertElementsCommand(scordCardData);
		
		 //insert fact 
       // InsertObjectCommand insertObjectCommand = new InsertObjectCommand(agencyControlRequestType,"Response");
        InsertObjectCommand insertObjectScorecardCommand = new InsertObjectCommand(scoreCard,"Response");
        
       // InsertObjectCommand insertObjectCommand1 = new InsertObjectCommand(prodconfig);
       
        //InsertObjectCommand list1 = new InsertObjectCommand(ls, "ls");
        //InsertObjectCommand insertObjectCommand2 = new InsertObjectCommand(per1);
        //InsertObjectCommand insertObjectCommand1 = new InsertObjectCommand(tr);
        //InsertObjectCommand insertObjectCommand = new InsertObjectCommand(model);
        
         //insertObjectCommand.setOutIdentifier("output");
       //insertObjectCommand1.setOutIdentifier("output");
       // insertObjectCommand.setEntryPoint("count");
       
        
        Command fireAllRulesCommand = CommandFactory.newFireAllRules();
        commands.add(scorcardDataCommand);
        commands.add(insertObjectScorecardCommand);
        commands.add(fireAllRulesCommand);
        commands.add(processCommand);

        String result = BatchExecutionHelper.newXStreamMarshaller().toXML(batchExecutionCommand);
        System.out.println(result);
        return result;
		
	}
	public static void main(String arq[]){
		//generate payload to test rule
		String payLoad = RuleScoreCardXmlPayload.marshelxml();
		
		/*CredentialsProvider credsProvider = new BasicCredentialsProvider();
		Credentials credi = (Credentials)new UsernamePasswordCredentials("username", "password");
        credsProvider.setCredentials(
                new AuthScope("localhost", 8080),
                credi);
        CloseableHttpClient httpClient2 = HttpClients.custom()
                .setDefaultCredentialsProvider(credsProvider)
                .build();
        try {
            HttpPost httppost = new HttpPost("http://localhost/");
            httppost.addHeader("content-type", "application/xml");
            
            httppost.setEntity(new StringEntity(payLoad));
            System.out.println("Executing request " + httppost.getRequestLine());
            CloseableHttpResponse response1 = httpClient2.execute(httppost);
           
                System.out.println("----------------------------------------");
                System.out.println(response1.getStatusLine());
                
					EntityUtils.consume(response1.getEntity());
				
					httpClient2.close();1
        } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
        	
        }*/


		
	}
}
